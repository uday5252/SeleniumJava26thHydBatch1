package com.abc.demo.FirstProject;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class LogoutTest {

	WebDriver driver;
	ExtentReports extentReport;
	ExtentTest test;
	
	@BeforeClass
	public void createReport()
	{
//			CREATE THE REPORT
		
		ExtentSparkReporter sparkReporter = 
				new ExtentSparkReporter("report.html");
		
		sparkReporter.config().setReportName("Gmail Report!");
		
		extentReport = new ExtentReports();
		extentReport.attachReporter(sparkReporter);
		
		extentReport.setSystemInfo("Tester Name", "Raju");
		
	}
	
	@Test
	public void clickLogout()
	{
		System.out.println("Logout click check!");
	}
	
	@AfterClass
	public void saveReport()
	{
		extentReport.flush();
	}
}
