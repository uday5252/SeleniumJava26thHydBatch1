//package com.abc.demo.FirstProject;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.edge.EdgeDriver;
//import org.testng.annotations.DataProvider;
//import org.testng.annotations.Test;
//
//public class LoginTest {
//
//	
//	@DataProvider
//	public Object[] browserProvider()
//	{
//		Object[] browsers = {"chrome", "edge"};
//		return browsers;
//	}
//	
//	WebDriver driver;
//	
//	@Test(dataProvider = "browserProvider")
//	public void validLogin(String browserName)
//	{
//		if(browserName.equals("chrome"))
//		{
//			driver = new ChromeDriver();
//			
//			driver.get("https://practicetestautomation.com/practice-test-login/");
//			
//			driver.findElement(By.id("username")).sendKeys("student");
//			
//			driver.findElement(By.id("password")).sendKeys("Password123");
//			driver.findElement(By.id("submit")).click();
//		}
//		if(browserName.equals("edge"))
//		{
//			driver = new EdgeDriver();
//			
//			driver.get("https://practicetestautomation.com/practice-test-login/");
//			
//			driver.findElement(By.id("username")).sendKeys("student");
//			
//			driver.findElement(By.id("password")).sendKeys("Password123");
//			driver.findElement(By.id("submit")).click();
//		}
//		
//		
//	}
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
////	WebDriver driver;
////	ExtentReports extentReport;
////	ExtentTest test;
////	
////	@BeforeClass
////	public void createReport()
////	{
//////			CREATE THE REPORT
////		
////		ExtentSparkReporter sparkReporter = 
////				new ExtentSparkReporter("report.html");
////		
////		sparkReporter.config().setReportName("Gmail Report!");
////		
////		extentReport = new ExtentReports();
////		extentReport.attachReporter(sparkReporter);
////		
////		extentReport.setSystemInfo("Tester Name", "Raju");
////		
////	}
////	
////	@BeforeMethod
////	public void setup()
////	{
////		driver = new ChromeDriver();
////		driver.get("https://practicetestautomation.com/practice-test-login/");
////	}
////	
////	@Test
////	public void validLogin()
////	{
////		test = extentReport.createTest("Login with valid username and a valid password!");
////		
////		test.info("entering the username!");
////		driver.findElement(By.id("username")).sendKeys("student");
////		test.pass("username is enetered!");
////		
////		driver.findElement(By.id("password")).sendKeys("Password123");
////		driver.findElement(By.id("submit")).click();
////	}
////	
////	@Test
////	public void invalidLogin()
////	{
////		test = extentReport.createTest("Invalid login with valid username and a invalid password!");
////		driver.findElement(By.id("username")).sendKeys("student");
////		driver.findElement(By.id("password")).sendKeys("Password5252");
////		driver.findElement(By.id("submit")).click();
////	}
////	
////	@AfterMethod
////	public void teardown()
////	{
////		driver.close();
////	}
////	
////	@AfterClass
////	public void saveReport()
////	{
////		extentReport.flush();
////	}
//}

//=====================================

package com.abc.demo.FirstProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class LoginTest {

	
	
	WebDriver driver;
	
	@Parameters("browser")
	@BeforeClass
	public void extractBrowserName(String browserName)
	{
		if(browserName.equals("chrome"))
		{
			driver = new ChromeDriver();
		}
		if(browserName.equals("edge"))
		{
			driver = new EdgeDriver();
		}
	}
	
	@Test
	public void validLogin()
	{
			driver.get("https://practicetestautomation.com/practice-test-login/");
			
			driver.findElement(By.id("username")).sendKeys("student");
			
			driver.findElement(By.id("password")).sendKeys("Password123");
			driver.findElement(By.id("submit")).click();
		}

}
